#include "cpress.hpp"

int main()
{

float temp = get_cpress();

return 1;
}
